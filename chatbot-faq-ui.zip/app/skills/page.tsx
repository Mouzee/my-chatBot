"use client"

import { AnimatedBackground } from "@/components/animated-background"
import { ThemeSwitcher } from "@/components/theme-switcher"
import { LanguageSwitcher } from "@/components/language-switcher"
import { ExpandableTabs } from "@/components/ui/expandable-tabs"
import { motion } from "framer-motion"
import { User, Briefcase, Code, Mail, BookOpen, Palette, Layout, Zap } from "lucide-react"
import { useTranslation } from "react-i18next"

export default function SkillsPage() {
  const { t } = useTranslation()

  const navigationTabs = [
    { title: t("navigation.home"), icon: User, href: "/" },
    { title: t("navigation.about"), icon: User, href: "/about" },
    { type: "separator" as const },
    { title: t("navigation.projects"), icon: Briefcase, href: "/projects" },
    { title: t("navigation.skills"), icon: Code, href: "/skills" },
    { type: "separator" as const },
    { title: t("navigation.contact"), icon: Mail, href: "/contact" },
    { title: t("navigation.blog"), icon: BookOpen, href: "/blog" },
  ]

  const skillCategories = [
    {
      icon: Layout,
      title: t("pages.skills.categories.0.title"),
      skills: t("pages.skills.categories.0.skills", { returnObjects: true }) as string[],
    },
    {
      icon: Code,
      title: t("pages.skills.categories.1.title"),
      skills: t("pages.skills.categories.1.skills", { returnObjects: true }) as string[],
    },
    {
      icon: Palette,
      title: t("pages.skills.categories.2.title"),
      skills: t("pages.skills.categories.2.skills", { returnObjects: true }) as string[],
    },
  ]

  return (
    <>
      <AnimatedBackground />
      <div className="fixed top-4 right-4 z-50 flex gap-2">
        <ThemeSwitcher />
        <LanguageSwitcher />
      </div>
      <main className="min-h-screen relative">
        <section className="min-h-screen flex items-center px-4 py-20">
          <div className="max-w-5xl mx-auto w-full">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              <div className="text-center space-y-4">
                <h1 className="text-4xl sm:text-5xl font-bold text-foreground">{t("pages.skills.title")}</h1>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("pages.skills.subtitle")}</p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mt-12">
                {skillCategories.map((category, index) => {
                  const Icon = category.icon
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: 0.1 * index }}
                      className="glass-card p-6 space-y-4"
                    >
                      <Icon className="w-8 h-8 text-primary" />
                      <h3 className="text-xl font-semibold">{category.title}</h3>
                      <ul className="space-y-2">
                        {category.skills.map((skill, skillIndex) => (
                          <li key={skillIndex} className="flex items-center gap-2 text-muted-foreground">
                            <Zap className="w-4 h-4 text-accent" />
                            <span>{skill}</span>
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  )
                })}
              </div>

              <motion.footer
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-12 pt-6 border-t border-border/30"
              >
                <ExpandableTabs tabs={navigationTabs} activeColor="text-primary" />
              </motion.footer>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  )
}
